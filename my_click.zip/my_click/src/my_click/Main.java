package my_click;

import my_click.domain.Card;
import my_click.domain.User;
import my_click.enums.CardTypeEnums;
import my_click.service.CardService;
import my_click.service.UserService;
import my_click.service.impl.CardServiceImpl;
import my_click.service.impl.UserServiceImpl;
import my_click.utils.StringUtils;

import java.util.Scanner;

public class Main {

    static Scanner scStr = new Scanner(System.in);
    static Scanner scInt = new Scanner(System.in);
    static UserService userService = new UserServiceImpl();
    static CardService cardService = new CardServiceImpl();

    public static void main(String[] args) {
        while (true) {
            System.out.println("""
                    1. Login :
                    2. Register :
                    0. Exit :
                    """);

            int userInput = scInt.nextInt();

            if (userInput == 0) {
                break;
            }

            if (userInput == 1) {
                System.out.println("Enter the password : ");
                String password = scStr.nextLine();
                System.out.println("Enter the name : ");
                String name = scStr.nextLine();
                var loggedUser = userService.login(password, name);
                if (loggedUser != null) {
                    userMenu(loggedUser);
                }
            } else if (userInput == 2) {
                System.out.println("Enter the name : ");
                String name = scStr.nextLine();
                System.out.println("Enter the password : ");
                String password = scInt.nextLine();
                User user = new User(name, password);
                var loggedUser = userService.registerUser(user);
                if (loggedUser != null) {
                    userMenu(user);
                }
            }
        }
    }

    private static void userMenu(User loggedUser) {
        while (true) {
            printUserMenu();
            int userIpnut = scInt.nextInt();

            if (userIpnut == 0) {
                break;
            }

            switch (userIpnut) {
                case 1 -> {
                    System.out.println("Enter the card name : ");
                    String name = scStr.nextLine();
                    System.out.println("Enter the card number : ");
                    String cardNumber = scStr.nextLine();
                    var result = StringUtils.weatherTheStringIsOnlyNumber(cardNumber);
                    if ((!result) && cardNumber.length() < 8) {
                        System.out.println("Invalid card number ");
                        break;
                    }
                    System.out.println("Enter the card before date ");
                    String beforeDate = scStr.nextLine();
                    if (!(beforeDate.charAt(2) == '/')) {
                        System.out.println("Invalid before date ");
                        break;
                    }
                    CardTypeEnums.printCardTypes();
                    System.out.println("Enter the card type index : ");
                    int index = scInt.nextInt();
                    var cardType = CardTypeEnums.getTypeByIndex(index);
                    Card card = new Card(name, loggedUser.getId(), cardNumber, beforeDate, cardType);
                    loggedUser.setCard(card);
                    getThreadUserAddCard(card).start();
                }
                case 2 -> {
                    cardService.showUserCards(loggedUser.getId());
                    System.out.println("Enter the card id : ");
                    Integer cardId = scInt.nextInt();
                    System.out.println("Enter the amount of money : ");
                    Integer check = scInt.nextInt();
                    getThreadUserAddMoney(cardId, loggedUser.getId(), check).start();
                }
                case 3 -> {
                    getThreadUserShowUserCards(loggedUser.getId()).start();
                }
                case 4 -> {
                    userService.showUsers(loggedUser.getId());
                    System.out.println("Which beneficiary do you want to send money to : ");
                    Integer toUserId = scInt.nextInt();
                    var res = userService.doesThePersonHave_A_Card(toUserId);
                    if (!res) {
                        System.out.println("The person you want to send money to does not have a card !");
                        return;
                    }
                    System.out.println("Enter the amount of money : ");
                    Integer check = scInt.nextInt();
                    cardService.showUserCards(loggedUser.getId());
                    System.out.println("Enter the card id : ");
                    Integer cardId = scInt.nextInt();
                    if (loggedUser.getCard().getCheck() > 100) {
                        getThreadUserSendMoney(toUserId, loggedUser.getId(), check, cardId).start();
                    } else {
                        System.out.println("To send money your account must be more than 100");
                    }
                }
            }
        }
    }

    private static void printUserMenu() {
        System.out.println("""
                1. Add card : 
                2. Add money card                
                3. Show user cards :
                4. Send money :
                0. Exit :
                """);
    }

    public static Thread getThreadUserAddCard(Card card) {
        return new Thread(() -> {
            cardService.addCard(card);
        });
    }

    public static Thread getThreadUserShowUserCards(Integer userId) {
        return new Thread(() -> {
            cardService.showUserCards(userId);
        });
    }

    public static Thread getThreadUserAddMoney(Integer cardId, Integer ownerId, Integer check) {
        return new Thread(() -> {
            userService.addUserCardMoney(cardId, ownerId, check);
        });
    }

    public static Thread getThreadUserSendMoney(Integer toUserId, Integer userId, Integer check, Integer cardId) {
        return new Thread(() -> {
            cardService.sendMoney(toUserId, userId, check, cardId);
        });
    }
}