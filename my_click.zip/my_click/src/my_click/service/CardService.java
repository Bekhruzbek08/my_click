package my_click.service;

import my_click.domain.Card;

public interface CardService {

    boolean doesTheCardExist(Card card);

    Card getCardByIndex(Integer id);

    String addCard(Card card);

    void showUserCards(Integer ownerId);

    void sendMoney(Integer toUserId, Integer userId, Integer check, Integer cardId);
}
