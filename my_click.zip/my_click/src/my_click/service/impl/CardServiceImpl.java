package my_click.service.impl;

import my_click.domain.Card;
import my_click.domain.User;
import my_click.service.CardService;

import static my_click.service.UserService.USERS;
import static my_click.service.UserService.USER_CARDS;

public class CardServiceImpl implements CardService {

    @Override
    public String addCard(Card card) {
        if (doesTheCardExist(card)) {
            return null;
        }
        USER_CARDS.add(card);
        return "Successfully";
    }

    @Override
    public void showUserCards(Integer ownerId) {
        for (Card card : USER_CARDS) {
            if (card.getOwnerId().equals(ownerId)) {
                System.out.println(card);
            }
        }
    }

    @Override
    public boolean doesTheCardExist(Card card) {
        for (Card card1 : USER_CARDS) {
            if (card1.getName().equals(card.getName())) {
                System.out.println("A card with this name exists !" + card1.getName());
                return true;
            } else if (card1.getCardNumber().equals(card.getCardNumber())) {
                System.out.println("A card with this number exists !" + card1.getCardNumber());
                return true;
            }
        }
        return false;
    }

    @Override
    public void sendMoney(Integer toUserId, Integer userId, Integer check, Integer cardId) {
        // todo you will do some logic here
    }

    @Override
    public Card getCardByIndex(Integer id) {
        for (Card card : USER_CARDS) {
            if (card.getId().equals(id)) {
                return card;
            }
        }
        return null;
    }
}
